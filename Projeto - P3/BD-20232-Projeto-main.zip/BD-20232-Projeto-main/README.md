﻿# BD-20232-Projeto


Altere o arquivo database.ini com os parametros da sua base de dados locais
